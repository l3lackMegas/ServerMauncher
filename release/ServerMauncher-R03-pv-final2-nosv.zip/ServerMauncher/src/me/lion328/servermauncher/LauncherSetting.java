package me.lion328.servermauncher;

public class LauncherSetting {

	public static String serverName = "";
	public static String minecraftDir = "";
	public static String authURL = ""; //falsec
	public static String dlURL = "";
	public static String hashURL = ""; //falsec
	public static String txtNewsURL = ""; //falsec
	public static String registerURL = ""; //falsec
	public static String title = "";
	public static String fileListURL = "";
	public static String launcherDL = ""; //falsec-sync(hashurl)
	
	public static final String version = "R03";

}
